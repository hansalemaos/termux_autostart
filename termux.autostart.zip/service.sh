#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != 1 ]; do
    sleep 1
done

while [[ ! -d "/sdcard" ]] || [[ ! -e "/system/bin/am" ]] || [[ ! -e "/system/bin/cmd" ]]; do
  sleep 3
done
# better config
/system/bin/am start --grant-read-uri-permission --grant-persistable-uri-permission --grant-prefix-uri-permission --grant-write-uri-permission --activity-no-animation "$(/system/bin/cmd package resolve-activity --brief "com.termux" | tail -n 1)"
#backup command 1 if the first one does not work, opens termux does a random action
monkey -p com.termux 1
sleep 3
# backup command 2, does nothing if the first one works
/system/bin/am start com.termux/.app.TermuxActivity
